package com.rnsoftware.solutions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
@ComponentScan(basePackages = {"com.rnsoftware.solutions"})
@EnableTransactionManagement
@EntityScan(basePackages = "com.rnsoftware.solutions.domain")
@Configuration
@EnableJpaRepositories(basePackages = "com.rnsoftware.solutions.repository")
@EnableScheduling
@EnableWebMvc
public class ApacheCamelApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApacheCamelApplication.class, args);
	}
}
