package com.rnsoftware.solutions.components;

import com.rnsoftware.solutions.service.UserService;
import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class UserRoute extends RouteBuilder {
    private static final Logger log = LoggerFactory.getLogger(UserRoute.class);
    private final UserService userService;
    private final UserProcessor userProcessor;

    public UserRoute(UserService userService, UserProcessor userProcessor) {
        this.userService = userService;
        this.userProcessor = userProcessor;
    }

    @Override
    public void configure() throws Exception {
        from("direct:createUser")
                .bean(userService, "create")
                .process(userProcessor);

        from("direct:getAllUsers")
                .bean(userService, "getAll");

        from("direct:getUserById")
                .bean(userService, "getById");

        from("direct:updateUser")
                .bean(userService, "update");

        from("direct:deleteUser")
                .bean(userService, "delete");

    }
}
