package com.rnsoftware.solutions.resource;

import com.rnsoftware.solutions.domain.User;
import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class);
    private final ProducerTemplate producerTemplate;
    public UserController(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }

    @PostMapping("/users/create")
    public ResponseEntity<?> create(@RequestBody User user) {
        log.info("REST Request to create: {}", user);
        String result = producerTemplate.requestBody("direct:createUser", user, String.class);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/users/list")
    public ResponseEntity<List<User>> getAll() {
        log.info("REST Request to getAll: {}");
        return ResponseEntity.ok(producerTemplate.requestBody("direct:getAllUsers", null, List.class));
    }

    @GetMapping("/users/fetch/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id) {
        log.info("REST Request to getById: {}", id);
        return ResponseEntity.ok(producerTemplate.requestBody("direct:getUserById", id));
    }

    @PutMapping("/users/update/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody User user) {
        log.info("REST Request to update: {}, {}", id, user);
        return ResponseEntity.ok(producerTemplate.requestBody("direct:updateUser", new Object[]{id, user}));
    }

    @DeleteMapping("/users/delete/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        log.info("REST Request to delete: {}", id);
        producerTemplate.sendBody("direct:deleteUser", id);
        return ResponseEntity.ok("Deleted");
    }
}
