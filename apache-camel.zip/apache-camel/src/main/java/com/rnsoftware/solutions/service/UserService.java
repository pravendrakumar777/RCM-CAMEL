package com.rnsoftware.solutions.service;

import com.rnsoftware.solutions.domain.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    User create(User user);
    List<User> getAll();
    Optional<User> getById(Long id);
    User update(Long id, User updated);
    void delete(Long id);
}
