package com.rnsoftware.solutions.service.impl;

import com.rnsoftware.solutions.domain.User;
import com.rnsoftware.solutions.repository.UserRepository;
import com.rnsoftware.solutions.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User create(User user) {
        log.info("Service Request to create: {}", user);
        return userRepository.save(user);
    }

    @Override
    public List<User> getAll() {
        log.info("Service Request to getAll: {}");
        List<User> result = userRepository.findAll();
        return result;
    }

    @Override
    public Optional<User> getById(Long id) {
        log.info("Service Request to getById: {}", id);
        return userRepository.findById(id);
    }

    @Override
    public User update(Long id, User updated) {
        log.info("Service Request to update: {}, {}", id, updated);
        User user = userRepository.findById(id).orElseThrow();
        user.setFirstName(updated.getFirstName());
        user.setLastName(updated.getLastName());
        user.setEmail(updated.getEmail());
        user.setMobile(updated.getMobile());
        user.setGender(updated.getGender());
        return userRepository.save(user);
    }

    @Override
    public void delete(Long id) {
        log.info("Service Request to delete: {}", id);
        userRepository.deleteById(id);
    }
}
