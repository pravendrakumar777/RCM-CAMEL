package com.rcm.engineering.resource;

import com.rcm.engineering.domain.Challan;
import com.rcm.engineering.resource.utils.PdfGeneratorUtil;
import com.rcm.engineering.service.ChallanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/api")
public class ChallanResource {
    private static final Logger log = LoggerFactory.getLogger(ChallanResource.class);
    private final ChallanService challanService;
    private final PdfGeneratorUtil pdfGeneratorUtil;
    public ChallanResource(ChallanService challanService, PdfGeneratorUtil pdfGeneratorUtil) {
        this.challanService = challanService;
        this.pdfGeneratorUtil = pdfGeneratorUtil;
    }

    // 1. Save Challan to DB
    @PostMapping("/challan")
    public ResponseEntity<Challan> createChallan(@RequestBody Challan challan) {
        log.info("REST Request to createChallan: {}", challan);
        return ResponseEntity.ok(challanService.saveChallan(challan));
    }
    // 2. Save + Generate PDF
    @PostMapping("/challan/generate")
    public ResponseEntity<?> generateChallan(@RequestBody Challan challan) {
        String generatedChallanNo = generateChallanNo();
        challan.setChallanNo(generatedChallanNo);
        try {
            Challan saved = challanService.saveChallan(challan);
            byte[] pdfBytes = PdfGeneratorUtil.generateChallanPDF(saved);

            return ResponseEntity.ok()
                    .contentLength(pdfBytes.length)
                    .contentType(MediaType.APPLICATION_PDF)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=challan_" + saved.getId() + ".pdf")
                    .body(new ByteArrayResource(pdfBytes));
        } catch (Exception e) {
            log.error("PDF generation failed", e);
            return ResponseEntity.status(500).body("Failed to generate Challan PDF");
        }
    }

    public String generateChallanNo() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        return "RCM-" + LocalDateTime.now().format(formatter);
    }
}
