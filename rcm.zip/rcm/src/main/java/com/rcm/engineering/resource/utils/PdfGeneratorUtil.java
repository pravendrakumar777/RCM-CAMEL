package com.rcm.engineering.resource.utils;

import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.VerticalAlignment;
import com.rcm.engineering.domain.Challan;
import com.rcm.engineering.domain.ChallanItem;
import freemarker.template.Configuration;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.format.DateTimeFormatter;

@Component
public class PdfGeneratorUtil {
    private final Configuration freemarkerConfig;
    public PdfGeneratorUtil(Configuration freemarkerConfig) {
        this.freemarkerConfig = freemarkerConfig;
    }
    private static String nonNull(String value) {
        return value == null ? "" : value;
    }

    public static byte[] generateChallanPDF(Challan challan) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdfDoc = new PdfDocument(writer);
        pdfDoc.addNewPage();
        Document doc = new Document(pdfDoc);

        // === Logo + Company Info in Table ===
        Table headerTable = new Table(UnitValue.createPercentArray(new float[]{1, 3}));
        headerTable.setWidth(UnitValue.createPercentValue(100));

        // Logo cell
        try {
            InputStream logoStream = PdfGeneratorUtil.class.getResourceAsStream("/static/images/logo.png");
            if (logoStream != null) {
                byte[] imageBytes = logoStream.readAllBytes();
                Image logo = new Image(ImageDataFactory.create(imageBytes))
                        .scaleAbsolute(100, 100);
                Cell logoCell = new Cell().add(logo).setBorder(Border.NO_BORDER);
                headerTable.addCell(logoCell);
            } else {
                headerTable.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
            }
        } catch (Exception e) {
            e.printStackTrace();
            headerTable.addCell(new Cell().add(new Paragraph("")).setBorder(Border.NO_BORDER));
        }

        // Company info cell
        Paragraph companyName = new Paragraph("RCM ENGINEERING & MANUFACTURING")
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(16)
                .setBold();

        Paragraph address = new Paragraph("KH NO: 513/1, 513/2, VILL BASAI, NEAR BASAI FLYOVER, GURUGRAM HR. 122001")
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(10);

        Paragraph contact = new Paragraph("Mob: 9639200584, 7819929402")
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(10);

        Cell infoCell = new Cell()
                .add(companyName)
                .add(address)
                .add(contact)
                .setVerticalAlignment(VerticalAlignment.MIDDLE)
                .setBorder(Border.NO_BORDER);

        headerTable.addCell(infoCell);
        doc.add(headerTable);

        // === Challan Info ===
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedDate = challan.getDate().format(formatter);

        doc.add(new Paragraph("\nChallan No: " + challan.getChallanNo() + "     Date: " + formattedDate));
        doc.add(new Paragraph("M/s: " + challan.getCustomerName()));

        // === Table Header ===
        float[] columnWidths = {30F, 200F, 100F, 100F, 60F};
        Table table = new Table(columnWidths);
        table.setWidth(UnitValue.createPercentValue(100));

        table.addHeaderCell("S. No");
        table.addHeaderCell("Particulars");
        table.addHeaderCell("Ref. Ch. No.");
        table.addHeaderCell("Weight");
        table.addHeaderCell("Qty");

        // === Table Rows ===
        int i = 1;
        for (ChallanItem item : challan.getItems()) {
            table.addCell(String.valueOf(i++));
            table.addCell(nonNull(item.getDescription()));
            table.addCell(nonNull(item.getRefChNo()));
            table.addCell(nonNull(item.getWeight()));
            table.addCell(String.valueOf(item.getQuantity()));
        }

        doc.add(table.setMarginTop(10));

        // === Footer ===
        doc.add(new Paragraph("\nFor : RCM ENGINEERING")
                .setTextAlignment(TextAlignment.RIGHT)
                .setBold());

        doc.add(new Paragraph("\nReceiver's Signature ____________________")
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(10));

        doc.add(new Paragraph("Authorised Signatory ____________________")
                .setTextAlignment(TextAlignment.RIGHT)
                .setFontSize(10));

        doc.close();
        return out.toByteArray();
    }
}
