package com.rcm.engineering.service.impl;

import com.rcm.engineering.domain.Challan;
import com.rcm.engineering.domain.ChallanItem;
import com.rcm.engineering.repository.ChallanRepository;
import com.rcm.engineering.service.ChallanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
public class ChallanServiceImpl implements ChallanService {
    private static final Logger log = LoggerFactory.getLogger(ChallanServiceImpl.class);
    private final ChallanRepository challanRepository;

    public ChallanServiceImpl(ChallanRepository challanRepository) {
        this.challanRepository = challanRepository;
    }

    @Override
    public Challan saveChallan(Challan challan) {
        log.info("Service Request to saveChallan: {}", challan);
        if (challan.getItems() != null) {
            for (ChallanItem item : challan.getItems()) {
                item.setChallan(challan);
            }
        }
        return challanRepository.save(challan);
    }

    @Override
    public Optional<Challan> getChallan(Long id) {
        log.info("Service Request to getChallan: {}", id);
        return challanRepository.findById(id);
    }
}
