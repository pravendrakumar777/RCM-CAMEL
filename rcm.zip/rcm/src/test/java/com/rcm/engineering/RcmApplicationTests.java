package com.rcm.engineering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RcmApplicationTests {

	@Test
	void contextLoads() {
	}

}
